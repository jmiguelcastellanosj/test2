
/**
 * <p>Title: Proyectil Simple</p>
 * <p>Description: Guarda un punto G</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Universidad de Sonora</p>
 * @author H�ctor Antonio Villa Mart�nez y Sa�l Robles Garc�a
 * @version 1.0
 */

public class GPoint
{
    public int xi, yi, x0, y0, xf, yf;

    public GPoint()
    {
        xi = yi = x0 = y0 = xf = yf = 0;
    }

}
