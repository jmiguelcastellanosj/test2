
/**
 * <p>Title: Proyecto Envolvente</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Universidad de Sonora</p>
 * @author H�ctor Antonio Villa Mart�nez y Sa�l Robles Garc�a
 * @version 1.0
 */

public class DatosXY {
  private double x, y;

  public DatosXY(double x, double y) {
    this.x = x;
    this.y = y;
  }

  public double getX ()
  {
    return x;
  }

  public double getY ()
  {
    return y;
  }
}
